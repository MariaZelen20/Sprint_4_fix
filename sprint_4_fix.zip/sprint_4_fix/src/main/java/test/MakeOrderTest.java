package test;

import org.junit.Test;
import page.BasePage;
import page.OrderPage;

import static page.BasePage.driver;

public class MakeOrderTest extends BasePage{
    public MakeOrderTest() {
        super(driver);
    }


    @Test
    public void makeOrder() {
        OrderPage orderPage = new OrderPage("Мария", "Зеленова", "Москва, Красносельская", "Красносельская", "+79371730518","25.07.2022");
        OrderPage isInputDataBlockDisplayed = (OrderPage) new BasePage(driver)
                .openUrl()
                .acceptCookie()
                .clickOrderButtonOverhead()
                .fillOrderDetailsForm(orderPage);

    }
}
