package page;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class OrderPage extends BasePage{


    private final By customerName = By.xpath(".//input[@placeholder = '* Имя']");
    private final By customerLastName = By.xpath(".//input[@placeholder = '* Фамилия']");
    private final By customerAddress = By.xpath(".//input[@placeholder = '* Адрес: куда привезти заказ']");
    private final By whenMetroStation = By.xpath(".//input[@class='select-search__input']");

    private final By customerPhone = By.xpath(".//input[@placeholder = '* Телефон: на него позвонит курьер']");

    private final By inputDataBlock = By.className("App_App__15LM-");
    private final By furtherButton = By.xpath(".//button[@class='Button_Button__ra12g Button_Middle__1CSJM']");

    private final By backButton = By.xpath(".//[@class=Button_Button__ra12g Button_Middle__1CSJM Button_Inverted__3IF-i]");
    // Форма 2. Поле 'Когда привезти самокат'
    private final By whenOrderDate = By.className("Input_Input__1iN_Z Input_Responsible__1jDKN");

    private String name;
    private String lastName;
    private String address;
    private String metroStation;
    private String phone;
    private String orderDate ;
    private String rentalPeriod;
    private String scooterColour;
    private String orderComment;

    public String getName() {
        return name;
    }

    public String getLastName() {

        return lastName;
    }

    public String getAddress() {
        return address;
    }

    public String getMetroStation() {
        return metroStation;
    }

    public String getPhone() {
        return phone;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public String getRentalPeriod() {
        return rentalPeriod;
    }

    public String getScooterColour() {
        return scooterColour;
    }

    public String getOrderComment() {
        return orderComment;
    }

    public OrderPage(String name, String lastName, String address, String metroStation, String phone, String orderDate) {
        super(driver);
        this.name = name;
        this.lastName = lastName;
        this.address = address;
        this.metroStation = metroStation;
        this.phone = phone;
        this.orderDate = orderDate;

    }

    //Выбор даты
    public OrderPage fillOrderDate(String orderDate) {
        driver.findElement(whenOrderDate).click();
        driver.findElement(whenOrderDate).sendKeys(orderDate + Keys.ENTER);
        return this;
    }

    public OrderPage fillRentalPeriod(String orderDate) {
        driver.findElement(whenOrderDate).click();
        driver.findElement(whenOrderDate).sendKeys(orderDate + Keys.ENTER);
        return this;
    }

    public OrderPage clickFurtherButton() {
        driver.findElement(furtherButton).click();
        return this;
    }

    public OrderPage fillPhone(String phone) {
        driver.findElement(customerPhone).sendKeys(phone);
        return this;
    }

    public OrderPage fillMetroStation(String metroStation) {
        driver.findElement(whenMetroStation).sendKeys(metroStation + Keys.ARROW_DOWN + Keys.ENTER);
        return this;
    }

    public OrderPage fillAddress(String address) {
        driver.findElement(customerAddress).sendKeys(address);
        return this;
    }

    public OrderPage fillLastName(String lastName) {
        driver.findElement(customerLastName).sendKeys(lastName);
        return this;
    }

    public OrderPage fillName(String name) {
        driver.findElement(customerName).sendKeys(name);
        return this;
    }



}
